@echo off
chcp 65001 >nul
setlocal DisableDelayedExpansion
title JH IPTV - Samsung TV
set TZ=C:\tizen-studio
set LG=en
for /f %%l in ('powershell -NoProfile -Command "(Get-Culture).TwoLetterISOLanguageName"') do set LG=%%l
if /i "%LG%"=="pt" goto L_pt
if /i "%LG%"=="es" goto L_es
if /i "%LG%"=="fr" goto L_fr
if /i "%LG%"=="de" goto L_de
if /i "%LG%"=="it" goto L_it
goto L_en
:L_pt
set "M1=O Tizen Studio não foi encontrado em C:\tizen-studio. Veja o guia, passos 2 e 3."
set "M2=Não existe o certificado «JHIPTV». Veja o guia, passo 8."
set "M3=Endereço IP da TV Samsung (ex.: 192.168.1.50): "
set "M4=Não foi possível ligar à TV. Confirme o modo de programador (passo 5) e que a TV e o computador estão na mesma rede."
set "M5=A preparar e instalar a JH IPTV na TV..."
set "M6=Pronto! A JH IPTV deve abrir agora na TV."
set "M7=A instalação falhou. Veja «Problemas comuns» no guia."
goto START
:L_en
set "M1=Tizen Studio was not found in C:\tizen-studio. See the guide, steps 2 and 3."
set "M2=The certificate "JHIPTV" does not exist. See the guide, step 8."
set "M3=Samsung TV IP address (e.g. 192.168.1.50): "
set "M4=Could not connect to the TV. Check developer mode (step 5) and that the TV and the computer are on the same network."
set "M5=Packaging and installing JH IPTV on the TV..."
set "M6=Done! JH IPTV should now open on the TV."
set "M7=Installation failed. See "Common problems" in the guide."
goto START
:L_es
set "M1=No se encontró Tizen Studio en C:\tizen-studio. Mira la guía, pasos 2 y 3."
set "M2=No existe el certificado «JHIPTV». Mira la guía, paso 8."
set "M3=Dirección IP de la TV Samsung (ej.: 192.168.1.50): "
set "M4=No se pudo conectar con la TV. Comprueba el modo desarrollador (paso 5) y que la TV y el ordenador estén en la misma red."
set "M5=Preparando e instalando JH IPTV en la TV..."
set "M6=¡Listo! JH IPTV debería abrirse ahora en la TV."
set "M7=La instalación falló. Mira «Problemas frecuentes» en la guía."
goto START
:L_fr
set "M1=Tizen Studio est introuvable dans C:\tizen-studio. Voir le guide, étapes 2 et 3."
set "M2=Le certificat « JHIPTV » n'existe pas. Voir le guide, étape 8."
set "M3=Adresse IP de la TV Samsung (ex. : 192.168.1.50) : "
set "M4=Connexion à la TV impossible. Vérifiez le mode développeur (étape 5) et que la TV et l'ordinateur sont sur le même réseau."
set "M5=Préparation et installation de JH IPTV sur la TV..."
set "M6=Terminé ! JH IPTV devrait maintenant s'ouvrir sur la TV."
set "M7=L'installation a échoué. Voir « Problèmes fréquents » dans le guide."
goto START
:L_de
set "M1=Tizen Studio wurde nicht in C:\tizen-studio gefunden. Siehe Anleitung, Schritte 2 und 3."
set "M2=Das Zertifikat „JHIPTV“ existiert nicht. Siehe Anleitung, Schritt 8."
set "M3=IP-Adresse des Samsung-Fernsehers (z. B. 192.168.1.50): "
set "M4=Keine Verbindung zum Fernseher. Entwicklermodus (Schritt 5) prüfen und ob Fernseher und Computer im selben Netzwerk sind."
set "M5=JH IPTV wird vorbereitet und auf dem Fernseher installiert..."
set "M6=Fertig! JH IPTV sollte sich jetzt auf dem Fernseher öffnen."
set "M7=Installation fehlgeschlagen. Siehe „Häufige Probleme“ in der Anleitung."
goto START
:L_it
set "M1=Tizen Studio non trovato in C:\tizen-studio. Vedi la guida, passi 2 e 3."
set "M2=Il certificato «JHIPTV» non esiste. Vedi la guida, passo 8."
set "M3=Indirizzo IP della TV Samsung (es.: 192.168.1.50): "
set "M4=Impossibile collegarsi alla TV. Controlla la modalità sviluppatore (passo 5) e che TV e computer siano sulla stessa rete."
set "M5=Preparazione e installazione di JH IPTV sulla TV..."
set "M6=Fatto! JH IPTV dovrebbe aprirsi ora sulla TV."
set "M7=Installazione non riuscita. Vedi «Problemi comuni» nella guida."
goto START
:START
setlocal EnableDelayedExpansion
echo.
echo   JH IPTV - Samsung TV
echo   ====================
echo.
if not exist "%TZ%\tools\ide\bin\tizen.bat" ( echo !M1! & echo. & pause & exit /b )
call "%TZ%\tools\ide\bin\tizen.bat" security-profiles list 2>nul | findstr /i "JHIPTV" >nul
if errorlevel 1 ( echo !M2! & echo. & pause & exit /b )
set /p IP=!M3!
"%TZ%\tools\sdb.exe" connect %IP% >nul 2>&1
set DEV=
for /f "tokens=3" %%a in ('"%TZ%\tools\sdb.exe" devices ^| findstr /c:"%IP%"') do set DEV=%%a
if "%DEV%"=="" ( echo. & echo !M4! & echo. & pause & exit /b )
echo.
echo !M5!
cd /d "%~dp0"
if exist "%~dp0JHIPTV.wgt" del "%~dp0JHIPTV.wgt" >nul
call "%TZ%\tools\ide\bin\tizen.bat" package -t wgt -s JHIPTV -o "%~dp0." -- "%~dp0app" > "%TEMP%\jhiptv-samsung.log" 2>&1
if not exist "%~dp0JHIPTV.wgt" ( echo. & echo !M7! & type "%TEMP%\jhiptv-samsung.log" & echo. & pause & exit /b )
call "%TZ%\tools\ide\bin\tizen.bat" install -n JHIPTV.wgt -t %DEV% >> "%TEMP%\jhiptv-samsung.log" 2>&1
findstr /i /c:"successfully" "%TEMP%\jhiptv-samsung.log" >nul
if errorlevel 1 ( echo. & echo !M7! & type "%TEMP%\jhiptv-samsung.log" & echo. & pause & exit /b )
call "%TZ%\tools\ide\bin\tizen.bat" run -p JhIptvPlr.JHIPTV -t %DEV% >nul 2>&1
echo.
echo !M6!
echo.
pause
